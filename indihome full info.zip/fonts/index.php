<?php
header('location: ../../');
?>